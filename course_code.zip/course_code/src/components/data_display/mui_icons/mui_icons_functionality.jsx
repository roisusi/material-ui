import DeleteIcon from "@mui/icons-material/DeleteTwoTone"

export function MuiIconsFunctionality() {
    return <DeleteIcon fontSize="large" color="secondary" />
}
