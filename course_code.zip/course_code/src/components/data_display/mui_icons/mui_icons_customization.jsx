import DeleteIcon from "@mui/icons-material/DeleteTwoTone"

export function MuiIconsCustomization() {
    return <DeleteIcon sx={{ fill: "orange", fontSize: 50 }} />
}
