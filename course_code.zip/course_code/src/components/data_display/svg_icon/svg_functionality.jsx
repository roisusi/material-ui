import { HomeIcon } from "./icons"

export function SvgIconFunctionality() {
    return <HomeIcon color="secondary" />
}
