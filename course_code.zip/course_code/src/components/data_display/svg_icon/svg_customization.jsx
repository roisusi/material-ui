import { HomeIcon } from "./icons"

export function SvgIconCustomization() {
    return <HomeIcon sx={{ fill: "#121212", fontSize: 50 }} />
}
